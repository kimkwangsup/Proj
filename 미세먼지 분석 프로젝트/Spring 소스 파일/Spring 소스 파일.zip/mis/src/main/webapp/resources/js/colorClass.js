var colorList = [
    'w3-red', 'w3-pink', 'w3-purple', 'w3-deep-purple', 'w3-indigo',
    'w3-blue', 'w3-aqua', 'w3-teal', 'w3-green', 'w3-light-green', 
    'w3-lime', 'w3-khaki', 'w3-yellow', 'w3-amber', 'w3-orange', 'w3-deep-orange',
    'w3-vivid-pink', 'w3-vivid-red', 'w3-vivid-orange', 'w3-vivid-yellow', 'w3-vivid-green','w3-vivid-blue',
    'w3-vivid-black', 'w3-vivid-white', 'w3-vivid-purple', 'w3-vivid-purple', 'w3-vivid-yellowish-pink', 'w3-vivid-reddish-orange',
    'w3-vivid-orange-yellow', 'w3-vivid-greenish-yellow', 'w3-vivid-yellow-green', 'w3-vivid-yellowish-green',
    'w3-vivid-bluish-green', 'w3-vivid-greenish-blue', 'w3-vivid-purplish-blue', 'w3-vivid-reddish-purple',
    'w3-vivid-purplish-red'
    ];