"""
URL configuration for boo project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from mungii import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/', views.index),
    path('kpred.mis/', views.k_pred, name="kpred"),
    path('kpredData.mis/', views.k_predData, name='kpredData'),
    path('weatherScheduler.mis/', views.make_PredData, name='getScheduler'),
    path('Scheduler.mis/', views.scheduler, name='Scheduler'),
    path('showChart.tm/', views.make_KNNChart, name='make_KNNChart'),

    path('pred/', views.mise, name='mise'),
    path('get_data/', views.get_data, name='get_data'), #콘솔창에서 데이터받음
    path('compare/', views.compare, name='compare'), #콘솔창에서 데이터받음
]
