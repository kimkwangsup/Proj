from django.apps import AppConfig


class BoogiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'boogi'
