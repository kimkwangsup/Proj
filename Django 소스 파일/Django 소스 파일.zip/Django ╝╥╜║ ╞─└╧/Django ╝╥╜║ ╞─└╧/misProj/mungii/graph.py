'''
    이 함수는 서브기능의 서울시 평당 매매가 그래프를 출력해주는 함수이다.
    @author  전민경
    @since	 2024.05.29
    @version V.1.0
			 2024.05.29 - 클래스 제작 [ 담당자 : 전민경 ] 
'''

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import cx_Oracle
from sqlalchemy import create_engine

def getPrice():
    dsn_tns = cx_Oracle.makedsn('localhost', '1521', service_name='xe')
    engine = create_engine(f'oracle+cx_oracle://boo:12345@{dsn_tns}')
    rd = pd.read_sql('select sgg_nm as 자치구명, acc_year as 접수연도, obj_amt as "물건금액(만원)", '
                     + 'round(bldg_area / 3.3) as "건물면적(㎡)" from sales where acc_year = 2023', engine)

    rd_price = round(rd.groupby(['자치구명'])['물건금액(만원)'].sum() / rd.groupby(['자치구명'])['건물면적(㎡)'].sum(), 2)
    rd_price = rd_price.reset_index()
    rd_price.columns = ['자치구', '평당매매가']

    fig = px.bar(rd_price, x='자치구', y='평당매매가', color='평당매매가', hover_name='자치구')
    fig.update_layout(
        width=1200,
        height=800,
        autosize=False,
        margin=dict(l=170, r=100, t=80, b=20)
    )
    plot_tag = fig.to_html(full_html=False)
    return plot_tag

