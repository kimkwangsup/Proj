// Google 지도 초기화 함수
function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 7,
        center: { lat: 36.3504119, lng: 127.3845475 } // 적절한 기본 중심 좌표
    });


    // json_data를 반복하여 마커 추가
    jsondata.forEach(function(item) {
        var latt = item['lat']; // 위도
        var lonn = item['lon']; // 경도
        var sname = item['cctvname']; // 마커의 타이틀
        var scode = item['cctvid'];

        var icon = {
            url: '/static/image/png.png', // 마커 이미지 URL
            scaledSize: new google.maps.Size(30, 30) // 조정된 이미지 크기
        };

        var marker = new google.maps.Marker({
            position: { lat: latt, lng: lonn },
            map: map,
            title: sname,
            icon: icon // 조정된 마커 이미지 사용
        });

        // 클로저를 사용하여 클릭 이벤트 리스너 추가
        marker.addListener('click', (function(marker, sname, scode) {
            return function() {
                console.log(sname, scode);
                var url = 'http://www.utic.go.kr/view/map/openDataCctvStream.jsp?key=jSCwqHY02Hb9Srt2fkSAi9gh2ldMPqgALc1YVGkLCTfErXroB9mU8eyhcVORKvpjpKuowcBBOztr7Sr8As1g&cctvid=' + scode + '&cctvName=' + sname + '&kind=KB&cctvip=9991&cctvch=null&id=null&cctvpasswd=null&cctvport=null';
                            
                // 새로운 URL로 이동
                window.location.href = url;
            };
        })(marker, sname, scode));
    });
}
