from django.test import TestCase

# Create your tests here.
def callback(request):
    if request.method == 'POST':
        try:
            payload = json.loads(request.body.decode('utf-8'))
            contexts = payload.get('contexts', [])
            if contexts:
                select_gu = contexts[0].get('params', {}).get('구이름', {}).get('resolvedValue', '')
            else:
                select_gu = ''
            user_message = payload.get('userRequest', {}).get('utterance', '')
            # 구 이름의 유무에 따른 조건처리 후 블럭 응답
            if not select_gu:
                template = {
                                "outputs": [
                                    {
                                        "simpleText": {
                                            "text": "말씀하신 내용을 이해할 수가 "
                                            + "없어요.\n\n다시 입력해 주세요."
                                        }
                                    }
                response = {
                    "version": "2.0",
                    "template": template
                }
                return JsonResponse(response)
            # DB에서 꺼내온 데이터가 비어있는 경우에 해당하는 블럭 응답
            if df_total.empty:
                title = f"{select_gu} {user_message}"
                description = '😢 해당 매물이 없습니다. 😢'
                items = [
                    {
                        "title": title,
                        "description": description,
                        "buttons": [
                            {
                                "label": "아파트 명 알고 싶어요.",
                                "action": "webLink",
                                "webLinkUrl": "http://58.72.151.124:6001/boo/list/list.boo?sgg_nm="+select_gu
                            }
                ]
            else:
                # DB에서 조회한 데이터를 가지고 매물 상세 조회.
                items = [
                    {
                        "title": f"{select_gu} {user_message}",
                        "description": "매물 정보입니다.",
                        "buttons": [
                            {
                                "label": "해당 아파트 지도 볼래요.",
                                "action": "webLink",
                                "webLinkUrl": url,
                            },
                            {
                                "label": "다른 아파트도 알고 싶어요.",
                                "action": "block",
                                "blockId": "664712f1f2800447c6289f79"
                            },
                            {
                                "label": "지역 정보를 보고 싶어요.",
                                "action": "block",
                                "blockId": "6646fb1ca6187865af6b0bce"
                            }
                        
                result_items = []
                for result_item in result:
                    result_items.append({
                        "title": '아파트명 : '+user_message+'\n―――――――――――――――',
                        "description": result_item,
                    })
                items += result_items
            template = {
                "outputs": [
                    {
                        "carousel": {
                            "type": "basicCard",
                            "items": items
                        }
                    }
                ],
                "quickReplies": [
                    {
                        "action": "block",
                        "label": "처음으로",
                        "blockId": "6646fb032260b1573785cef4",
                    },
                    {
                        "action": "block",
                        "label": "매매시 주의사항",
                        "blockId": "665538210ed18d50aeb8a8e8",
                    },
                    # 이하 생략...
                ]
            }
            response = {
                "version": "2.0",
                "template": template
            }
            return JsonResponse(response)
        except json.JSONDecodeError as e:
            return HttpResponse(status=400)
        except Exception as e:
            return HttpResponse(status=500)
    return HttpResponse(status=405)